#!/bin/bash
./ls-recursive-Nov-2011-jpg.sh | wc -l
