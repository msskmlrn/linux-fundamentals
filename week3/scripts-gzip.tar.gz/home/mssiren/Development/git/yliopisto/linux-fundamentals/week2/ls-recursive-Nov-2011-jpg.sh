#!/bin/bash
./ls-recursive-Nov-2011.sh | grep "\.jpg$"
