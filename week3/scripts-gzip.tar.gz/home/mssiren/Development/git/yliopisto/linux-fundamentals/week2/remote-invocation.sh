#!/bin/bash
foo=$(ssh $1 $2)
echo $foo
