#!/bin/bash
echo "rsync --archive ~tkt_cam/public_html/`date +%Y`/`date +%m`/`date +%d`/ ~/Development/git/yliopisto/linux-fundamentals/week1/`date +%A:%Y:%m:%d`/ --stats"
