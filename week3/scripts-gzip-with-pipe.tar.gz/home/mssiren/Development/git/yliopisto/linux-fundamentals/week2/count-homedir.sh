#!/bin/bash
ls ~ | wc -l

